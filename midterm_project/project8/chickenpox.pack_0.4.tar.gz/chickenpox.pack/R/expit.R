#' Expit Function
#'
#' This function allows you to do the expit transformation, the inverse of the logit transformation.
#' @param x
#' @keywords expit, logit
#' @export
#' @examples
#' expit(0.5) 
expit<- function(x=NULL){
	val= 1.0/(1.0+exp(-x));
	return(val);
}