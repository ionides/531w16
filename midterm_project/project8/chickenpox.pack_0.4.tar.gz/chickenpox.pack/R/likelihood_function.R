#' Function for running particles filters to calculate the log-likelihood
#'
#' This function allows you to run particle fileters with 10 replicates and 2000 particles each
#' @param POMP.OBJ What is the name of your pomp object?
#' @param PARS What are your parameters? Must be a named vector.
#' @keywords pfilter, particle filter, likelihood
#' @export
#' @examples
#' full.model.pomp.object<- full.model(COUNTRY='Australia')
#' params <- full.mles[1,]
#' trans.params <- unlist(c(log(params[1:7]),logit(params[8]),params[9:10]))
#' est.likelihood<- likelihood.calc(POMP.OBJ=full.model.pomp.object,PARS=trans.params)['LogLik']
#' sim<- pomp::simulate(full.model.pomp.object,params=trans.params)
#' pomp::plot(sim)
#' print(est.likelihood)
likelihood.calc<- function(POMP.OBJ,PARS){
	loglik.mif<- replicate(n=10,pomp::logLik(pomp::pfilter(POMP.OBJ,params=PARS,Np=2000,max.fail=180)))
		bl<- mean(loglik.mif)
		loglik.mif.est<- bl+log(mean(exp(loglik.mif-bl)))
		loglik.mif.se <- sd(exp(loglik.mif-bl))/sqrt(length(loglik.mif))/exp(loglik.mif.est-bl)	
	return(c(LogLik=loglik.mif.est,seLogLik=loglik.mif.se));
}