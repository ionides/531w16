#' Logit Function
#'
#' This function allows you to do the logit transformation, which will bound values between 0 and 1.
#' @param p
#' @keywords expit, logit
#' @export
#' @examples
#' logit(5)
logit<- function(p=NULL){
	val= log(p/(1-p));
	return(val);
}
