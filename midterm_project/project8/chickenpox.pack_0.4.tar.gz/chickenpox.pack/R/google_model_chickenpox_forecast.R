#' Construct pomp object for forecasting chickenpox cases using google trends data
#'
#' This function allows you to construct the pomp object for either Australia or Thailand
#' @param COUNTRY Do you want the pomp object for "Australia" or "Thailand"? No Default.
#' @keywords chickenpox, google trends
#' @export
#' @useDynLib chickenpox.pack
#' @examples
#' full.model(COUNTRY='Australia')

# pomp and c-code MUST be loaded to use this function
# last modified by Micaela Martinez-Bakker on June 21, 2015
# must define COUNTRY, options are "Australia" and "Thailand"
# this function will return the pomp object for the country specified
full.model<- function(COUNTRY){
  #######################################################################################################
  # Load the chickenpox case data
  #######################################################################################################
  if(COUNTRY=='Australia'){
    data('chickenpox_cases_Australia')
    dat<- chickenpox.Australia
  }
  if(COUNTRY=='Thailand'){
    data('chickenpox_cases_Thailand')
    dat<- chickenpox.Thailand
  }

  # only working with data up to December 2014
  dat<- subset(dat,time<= 2015)
  dat$time<- round(dat$time,digits=3)

  #######################################################################################################
  # Load the GOOGLE trends data
  #######################################################################################################
  data('monthly_google_trends_data') # the data frame that's loaded is named google.trends
  goog<- google.monthly
  goog<- subset(goog,country==COUNTRY)

  # only working with data up to December 2014
  goog<- subset(goog,time<=2015)
  goog$time<- round(goog$time,digits=3)

  #######################################################################################################
  # identify years where google and case data overlap
  #######################################################################################################
  MIN.TIME<- max(c(min(dat$time),min(goog$time)))
  MAX.TIME<- min(c(max(dat$time),max(goog$time)))

  # subset both data sets so they are overlapping in time
  dat<- subset(dat,time>=MIN.TIME & time<=MAX.TIME)
  goog<- subset(goog,time>=MIN.TIME & time<=MAX.TIME)

  # set up the timestep
  dat$timestep<- 1:dim(dat)[1]
  goog$timestep<- 1:dim(dat)[1]

  #######################################################################################################
  # load the population data for the 0-14 year old age class
  #######################################################################################################
  data('country_level_population_0_to_14_years_old') # the data frame that gets loaded is named data.population
  pop<- population
  pop<- subset(pop,location==COUNTRY)

  # we are only using the data from 2010
  pop2010<- subset(pop,year==2010)

  #######################################################################################################
  # Set up a data frame containing the covariates (don't include the data)
  #######################################################################################################
  covar.table<- data.frame(timestep=dat$timestep,MONTH.YR=dat$time)

  # number of children, assume fixed at the 2010 UN estimate for the country
  covar.table$children <- pop2010$pop_0_to_14

  # get the lag0, lag1, and lag2 google trends data
  covar.table$googleLAG0<- NA
  covar.table$googleLAG1<- NA
  covar.table$googleLAG2<- NA 
  for(i in 1:dim(covar.table)[1]){
    TIME<- covar.table$MONTH.YR[i]
    covar.table$googleLAG0[i]<- goog$google.trend[which(goog$time==TIME)]
    if(i>=2){covar.table$googleLAG1[i]<- goog$google.trend[which(goog$time==TIME)-1]} 
    if(i>=3){covar.table$googleLAG2[i]<- goog$google.trend[which(goog$time==TIME)-2]}
  }

  #######################################################################################################
  # Set up data frame with the data to be fit, this dataframe should start at timestep==1
  #######################################################################################################
  monthly.cases<- dat[c('timestep','chickenpox.cases')]
  # start the observations at timestep==3, the first observation for which we have the google trends lag2 covariate
  monthly.cases<- subset(monthly.cases,timestep>=3)

  #######################################################################################################
  # POMP Object
  #######################################################################################################
  my.model<- pomp::pomp(
                data=monthly.cases[c("timestep","chickenpox.cases")], # data are cases and associated timestep, starting w/ timestep==1
                times="timestep", # name of time variable in data dataframe
                rprocess=pomp::euler.sim("chickenpox_proc_sim",delta.t=1,PACKAGE="chickenpox.pack"), # chickenpox_proc_sim is the name of our process model in C-code; chickenpox.c is the name of our C file; see ?plugins for integration options
                rmeasure="chickenpox_meas_sim", # name of measurement model in C-code
                dmeasure="chickenpox_meas_dens", # name of measurement density model in C-code
                PACKAGE="chickenpox.pack", # name of dynamically loaded library
                t0=3, # this is the time we initialize the model, starting at timestep=3 so that we have lag2 google trends data
                obsnames="chickenpox.cases", # name of observations in data dataframe
                statenames=c("FOI","I"), # process model state variable names, this vector must match the order of the states in (x[stateindex[i]]) in C-code
                covarnames=c("MONTH.YR","children","googleLAG0","googleLAG1","googleLAG2"), # covariate names, must match order of (covar[covindex[i]]) in C-code
                paramnames=c('alpha','tau','beta1','beta2','beta3','beta.sd','rho','omega'), # param names, must match order of (p[parindex[i]]) in C-code, but notice the actual name doesn't have to match for instance here we use "alpha" in C-code we call it LOGALPHA, only the indexing matters not the exact name
                tcovar="timestep", # name of the time variable in the covariate data frame
                covar=covar.table # name of the covariate dataframe
              )

  #######################################################################################################
  # END pomp object construction
  #######################################################################################################
  #######################################################################################################
  return(my.model)
}
