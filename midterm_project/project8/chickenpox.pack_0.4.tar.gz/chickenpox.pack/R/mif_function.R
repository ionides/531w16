#' Function for running mif
#'
#' This function allows you to run mif with pre-specified mif parameters
#' @param POMP.OBJ What is the name of your pomp object?
#' @param START.PARAMS What are your starting parameters? Must be a named vector.
#' @param RANDOM.WALK.PARAMS What are the random walk standard deviations for the parameters you are estimating? Must be a named vector.
#' @keywords mif
#' @export
#' @examples
#' full.model.pomp.object<- full.model(COUNTRY='Australia')
#' params <- full.mles[1,]
#' trans.params <- unlist(c(log(params[1:7]),logit(params[8]),params[9:10]))
#' random.walk.pars<- rep(0.2,7)
#' names(random.walk.pars)<- names(params)[1:7]
#' mif.results<- run.mif(POMP.OBJ=full.model.pomp.object,START.PARAMS=trans.params,RANDOM.WALK.PARAMS=random.walk.pars)
#' new.params.log.logit.scale<- pomp::coef(mif.results)
#' new.params<- c(exp(new.params.log.logit.scale[1:7]),expit(new.params.log.logit.scale[8]),new.params.log.logit.scale[9:10])
#' names(new.params)<- names(new.params.log.logit.scale)
#' print(new.params)
run.mif<- function(POMP.OBJ,START.PARAMS,RANDOM.WALK.PARAMS){
	mif.run= pomp::mif(object=POMP.OBJ,
				Nmif=45,
				start=START.PARAMS,
				rw.sd=RANDOM.WALK.PARAMS,
				Np=2000,
				var.factor=2,
				cooling.type='hyperbolic',
				cooling.fraction.50=0.5,
				method='mif2',
				max.fail=150
			)
	return(mif.run)
}


